// Copyright 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:async';

import 'package:flutter_clock_helper/model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:random_string/random_string.dart';

enum _Element {
  background,
  text,
  shadow,
  randomText,
}

final _lightTheme = {
  _Element.background: Color.fromRGBO(168, 139, 43, 1),
  _Element.text: Colors.white,
  _Element.shadow: Colors.black,
};

final _darkTheme = {
  _Element.background: Colors.black,
  _Element.text: Colors.white,
  _Element.shadow: Color(0xFF174EA6),
};

/// A basic digital clock.
///
/// You can do better than this!
class DigitalClock extends StatefulWidget {
  const DigitalClock(this.model);

  final ClockModel model;

  @override
  _DigitalClockState createState() => _DigitalClockState();
}

class _DigitalClockState extends State<DigitalClock> {
  DateTime _dateTime = DateTime.now();
  Timer _timer;

  @override
  void initState() {
    super.initState();
    widget.model.addListener(_updateModel);
    _updateTime();
    _updateModel();
  }

  @override
  void didUpdateWidget(DigitalClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.model != oldWidget.model) {
      oldWidget.model.removeListener(_updateModel);
      widget.model.addListener(_updateModel);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.model.removeListener(_updateModel);
    widget.model.dispose();
    super.dispose();
  }

  void _updateModel() {
    setState(() {
      // Cause the clock to rebuild when the model changes.
    });
  }

  void _updateTime() {
    setState(() {
      _dateTime = DateTime.now();
      // Update once per minute. If you want to update every second, use the
      // following code.
      _timer = Timer(
        Duration(minutes: 1) -
            Duration(seconds: _dateTime.second) -
            Duration(milliseconds: _dateTime.millisecond),
        _updateTime,
      );
    });
  }

  List<Container> getTime(String time) {
    return time
        .split('')
        .map((s) => Container(
              width: 40,
              child: Center(
                child: s != ' '
                    ? Text(s)
                    : Text(
                        randomAlpha(1).toUpperCase(),
                        style: TextStyle(
                          color:
                              Theme.of(context).brightness == Brightness.light
                                  ? Color.fromRGBO(176, 166, 26, 1)
                                  : Colors.blueGrey[900],
                        ),
                      ),
              ),
            ))
        .toList();
  }

  List<Container> getRandomString(String time) {
    return time
        .split('')
        .map((s) => Container(
              width: 40,
              child: Center(
                child: Text(
                  s,
                  style: TextStyle(
                      color: Theme.of(context).brightness == Brightness.light
                          ? Color.fromRGBO(176, 166, 26, 1)
                          : Colors.blueGrey[900]),
                ),
              ),
            ))
        .toList();
  }

  List<Widget> getChar(String str) {
    var len = 15 - str.length;
    var diff = len - randomBetween(1, len);
    return getRandomString(randomAlpha(diff).toUpperCase()) +
        getTime(str) +
        getRandomString(randomAlpha(len - diff).toUpperCase());
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).brightness == Brightness.light
        ? _lightTheme
        : _darkTheme;
    const numberMap = {
      '00': 'O CLOCK',
      '01': 'ONE',
      '02': 'TWO',
      '03': 'THREE',
      '04': 'FOUR',
      '05': 'FIVE',
      '06': 'SIX',
      '07': 'SEVEN',
      '08': 'EIGHT',
      '09': 'NINE',
      '10': 'TEN',
      '11': 'ELEVEN',
      '12': 'TWELVE',
      '13': 'THIRTEEN',
      '14': 'FOURTEEN',
      '15': 'FIFTEEN',
      '16': 'SIXTEEN',
      '17': 'SEVENTEEN',
      '18': 'EIGHTEEN',
      '19': 'NINTEEN',
      '20': 'TWENTY',
      '21': 'TWENTY ONE',
      '22': 'TWENTY TWO',
      '23': 'TWENTY THREE',
      '24': 'TWENTY FOUR',
      '25': 'TWENTY FIVE',
      '26': 'TWENTY SIX',
      '27': 'TWENTY SEVEN',
      '28': 'TWENTY EIGHT',
      '29': 'TWENTY NINE',
      '30': 'HALF',
    };
    var hour =
        DateFormat(widget.model.is24HourFormat ? 'HH' : 'hh').format(_dateTime);
    final minute = DateFormat('mm').format(_dateTime);
    var min = int.parse(minute);
    bool isMinLessThan = min <= 30;
    var hr = int.parse(hour) + 1;
    var nextHour = hr > 9 ? hr.toString() : '0' + hr.toString();
    var hourText = isMinLessThan ? numberMap[hour] : numberMap[nextHour];
    var temp = (isMinLessThan ? min : 30 - (min - 30)).toString();
    var seperator = min != 0 ? (isMinLessThan ? 'PAST' : 'TO') : '';
    temp = temp.length == 2 ? temp : '0' + temp;
    var minuteText = min == 15 || min == 45 ? 'QUARTER' : numberMap[temp];
    if (min == 0) {
      var t = hourText;
      hourText = minuteText;
      minuteText = t;
    }
    final fontSize = MediaQuery.of(context).size.width / 25;
    final defaultStyle = TextStyle(
      color: colors[_Element.text],
      fontSize: fontSize,
      fontWeight: FontWeight.bold,
    );

    return Container(
      color: colors[_Element.background],
      child: Center(
        child: DefaultTextStyle(
          style: defaultStyle,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              // Text('IT IS'),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  ...getChar('IT IS'),
                ],
              ),
              Row(
                children: <Widget>[
                  ...getChar(minuteText),
                ],
              ),
              Row(
                children: <Widget>[
                  ...getChar(seperator),
                ],
              ),
              Row(
                children: <Widget>[
                  ...getChar(hourText),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
